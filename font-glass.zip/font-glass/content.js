(() => {
  'use strict';
  if (globalThis.__fontGlassLoaded) return;
  globalThis.__fontGlassLoaded = true;

  const mark = 'data-font-glass-target';
  const shield = 'data-font-glass-preserve';
  const fontCSS = document.createElement('style');
  const sizeCSS = document.createElement('style');
  fontCSS.id = 'font-glass-styles';
  sizeCSS.id = 'font-glass-sizes';

  // Non-text subtrees that should never be measured with getComputedStyle
  const deadTree = 'script,style,noscript,svg,math,canvas,iframe,object,embed,head,meta,link,audio,video,picture,source,track';
  const skipped = 'script,style,noscript,svg,math,canvas,pre,code,kbd,samp,textarea,[contenteditable]:not([contenteditable="false"]),[role="img"],[aria-hidden="true"]';
  const icon = /icon|awesome|material\s*(symbols|icons)|glyph|wingdings|webdings|symbol|codicon|octicon|feather|nerdfont|nerd\s*font|phosphor|tabler|lucide|remixicon/i;
  const textTags = 'body,div,span,p,a,li,ul,ol,dl,dt,dd,h1,h2,h3,h4,h5,h6,label,button,input,select,option,summary,details,blockquote,td,th,caption,legend,small,strong,b,em,i,section,article,main,header,footer,nav,aside,time,output';

  let settings = {};
  let key = '';
  let observer;
  let timer = 0;
  let resizeTimer = 0;
  let cache = new WeakMap();
  let groups = new Map();
  let shieldGroups = new Map();
  const pending = new Set();

  const selector = (attr, id) => `html body [${attr}="${id}"][${attr}],html body[${attr}="${id}"]`;

  function topHost() {
    if (location.ancestorOrigins?.length) {
      try {
        return new URL(location.ancestorOrigins[location.ancestorOrigins.length - 1]).hostname || location.hostname;
      } catch {}
    }
    try {
      return window.top.location.hostname || location.hostname;
    } catch {
      try {
        return new URL(document.referrer).hostname || location.hostname;
      } catch {
        return location.hostname;
      }
    }
  }

  function allowed() {
    if (!settings.enabled) return false;
    const ex = settings.excluded;
    if (!Array.isArray(ex) || !ex.length) return true;
    return !ex.includes(topHost()) && !ex.includes(location.hostname);
  }

  function codeLigatureCSS() {
    if (settings.codeLigatures === 'normal') {
      return 'font-variant-ligatures:normal!important;font-feature-settings:"liga" 1,"calt" 1!important;';
    }
    if (settings.codeLigatures === 'none') {
      return 'font-variant-ligatures:none!important;font-feature-settings:"liga" 0,"calt" 0!important;';
    }
    return '';
  }

  function typography() {
    return !!(
      settings.family ||
      settings.codeFamily ||
      settings.codeLigatures === 'normal' ||
      settings.codeLigatures === 'none' ||
      settings.sizeMode === 'scale' ||
      settings.sizeMode === 'fixed' ||
      ['normal', 'italic'].includes(settings.italic)
    );
  }

  function mount(sheet) {
    if (!sheet.isConnected) (document.head || document.documentElement).append(sheet);
  }

  function clear() {
    fontCSS.remove();
    sizeCSS.remove();
    document.querySelectorAll(`[${mark}],[${shield}]`).forEach(el => {
      el.removeAttribute(mark);
      el.removeAttribute(shield);
    });
    cache = new WeakMap();
    groups = new Map();
    shieldGroups = new Map();
    pending.clear();
  }

  function rule(sheet, css) {
    sheet.sheet.insertRule(css, sheet.sheet.cssRules.length);
  }

  function observe() {
    observer.observe(document.documentElement, { subtree: true, childList: true });
  }

  function hasDirectText(el) {
    for (let n = el.firstChild; n; n = n.nextSibling) {
      if (n.nodeType === 3 && n.nodeValue.trim()) return true;
    }
    return false;
  }

  function process(elements) {
    if (!allowed() || !typography()) return;
    observer.disconnect();
    try {
      const relative = settings.sizeMode === 'scale';
      const fixed = settings.sizeMode === 'fixed';
      const needSize = relative || fixed;
      if (relative) sizeCSS.disabled = true;

      const reads = [];
      for (const el of elements) {
        if (!el.isConnected || cache.has(el) || el.matches(deadTree) || el.closest(deadTree)) continue;
        const cs = getComputedStyle(el);
        reads.push([el, {
          family: cs.fontFamily,
          size: needSize ? cs.fontSize : '',
          italic: cs.fontStyle
        }]);
      }

      if (relative) sizeCSS.disabled = false;

      const codeLig = codeLigatureCSS();
      for (const [el, data] of reads) {
        cache.set(el, data);
        const excluded = el.closest(skipped);
        const primaryFont = data.family.split(',')[0].replace(/["']/g, '').trim();
        const isIcon = icon.test(primaryFont);

        if (excluded || isIcon) {
          if (isIcon || (el.matches(skipped) && !el.parentElement?.closest(skipped))) {
            const isCode = el.matches('pre,code,kbd,samp');
            const targetFam = isCode && settings.codeFamily
              ? `${JSON.stringify(settings.codeFamily)},monospace`
              : data.family;
            const ligRule = isCode ? codeLig : '';
            const sKey = `${targetFam}|${data.italic}|${ligRule}|${needSize ? data.size : ''}`;
            let sId = shieldGroups.get(sKey);
            if (sId === undefined) {
              sId = String(shieldGroups.size);
              shieldGroups.set(sKey, sId);
              rule(fontCSS, `${selector(shield, sId)}{font-family:${targetFam}!important;font-style:${data.italic}!important;font-variation-settings:normal!important;${ligRule}}`);
              if (needSize && data.size) {
                rule(sizeCSS, `${selector(shield, sId)}{font-size:${data.size}!important;}`);
              }
            }
            el.setAttribute(shield, sId);
          }
          continue;
        }

        if (!el.matches(textTags) && !hasDirectText(el)) continue;
        if (el.matches('input') && !/^(text|search|email|url|tel|password|number|button|submit|reset)$/.test(el.type)) continue;

        let size = '';
        if (relative) {
          size = (parseFloat(data.size) * Math.min(200, Math.max(50, Number(settings.scale) || 100)) / 100).toFixed(3) + 'px';
        } else if (fixed) {
          size = Math.min(72, Math.max(8, Number(settings.fixed) || 16)) + 'px';
        }

        let id = groups.get(size);
        if (id === undefined) {
          id = String(groups.size);
          groups.set(size, id);
          if (size) rule(sizeCSS, `${selector(mark, id)}{font-size:${size}!important;}`);
        }
        el.setAttribute(mark, id);
      }
    } finally {
      sizeCSS.disabled = false;
      if (allowed()) observe();
    }
  }

  function full(force = false) {
    const next = JSON.stringify(settings);
    if (!force && key === next) return;
    key = next;
    observer.disconnect();
    clear();
    if (!allowed() || !typography()) return;

    const family = settings.family ? `font-family:${JSON.stringify(settings.family)},sans-serif!important;` : '';
    const italic = ['normal', 'italic'].includes(settings.italic) ? `font-style:${settings.italic}!important;` : '';
    const weightNum = Number(settings.varWeight);
    const varWeight = (settings.family && settings.varWeightEnabled && Number.isFinite(weightNum) && weightNum >= 50 && weightNum <= 1000)
      ? `font-variation-settings:"wght" ${weightNum}!important;font-weight:${Math.round(weightNum)}!important;`
      : '';

    fontCSS.textContent = `html body [${mark}][${mark}],html body[${mark}]{${family}${italic}${varWeight}}`;

    const codeFam = settings.codeFamily ? `font-family:${JSON.stringify(settings.codeFamily)},monospace!important;` : '';
    const codeLig = codeLigatureCSS();
    if (codeFam || codeLig) {
      fontCSS.textContent += `html body :is(pre,code,kbd,samp),html body :is(pre,code,kbd,samp) *:not([${shield}]){${codeFam}${codeLig}}`;
    }

    if (/(^|\.)youtube\.com$/.test(location.hostname) && settings.family) {
      fontCSS.textContent += `html body :is(ytd-searchbox,yt-searchbox,.ytSearchboxComponentInputBox) input,html body input[name="search_query"]{${family}${italic}${varWeight}}`;
    }

    sizeCSS.textContent = '';
    mount(fontCSS);
    mount(sizeCSS);
    if (document.body) {
      process(document.querySelectorAll('body,body *'));
    }
  }

  function enqueue(nodes) {
    for (const node of nodes) {
      if (node.nodeType === 1 && !node.matches(deadTree)) pending.add(node);
    }
    if (timer || !pending.size) return;
    timer = requestAnimationFrame(() => {
      timer = 0;
      const els = new Set();
      for (const node of pending) {
        if (!node.isConnected || node.matches(deadTree) || node.closest(deadTree)) continue;
        els.add(node);
        node.querySelectorAll('*').forEach(el => {
          if (!el.matches(deadTree)) els.add(el);
        });
      }
      pending.clear();
      if (els.size) process(els);
    });
  }

  observer = new MutationObserver(records => {
    for (const r of records) {
      if (r.addedNodes.length) enqueue(r.addedNodes);
    }
  });

  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (message?.type !== 'font-glass-refresh') return;
    reload()
      .then(() => {
        respond({
          ok: true,
          targets: document.querySelectorAll(`[${mark}]`).length,
          enabled: allowed()
        });
      })
      .catch(error => respond({ ok: false, error: String(error) }));
    return true;
  });

  const defaults = {
    enabled: true,
    family: '',
    sizeMode: 'original',
    italic: 'original',
    varWeightEnabled: false,
    varWeight: 400,
    codeFamily: '',
    codeLigatures: 'original'
  };
  let loadEpoch = 0;

  async function reload() {
    const epoch = ++loadEpoch;
    const data = await chrome.storage.local.get(['settings', 'importedFonts']);
    const next = { ...defaults, ...data.settings };
    delete next.oled;
    await FontGlassFonts.sync(data.importedFonts || [], next.enabled ? [next.family, next.codeFamily] : []);
    if (epoch !== loadEpoch) return;
    settings = next;
    full();
  }

  reload().catch(console.error);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && (changes.settings || changes.importedFonts)) {
      reload().catch(console.error);
    }
  });

  window.addEventListener(
    'resize',
    () => {
      if (settings.sizeMode !== 'scale') return;
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => full(true), 250);
    },
    { passive: true }
  );
})();
